package lab4;

import java.util.List;
import java.util.Scanner;

public class Main {
	private static List<String> lines;
	private static FA fa = new FA();

	public static void main(String[] args) {
		lines = FileUtil.loadFile("fa.txt");
		fa.parseLines(lines);
		startUI();
	}

	/**
	 * Starts the ui, shows the menu and checks the option written by the user
	 */
	private static void startUI() {
		while (true) {
			showMenu();
			System.out.println("What do you want to see?");
			String option = ReadString();
			System.out.println();
			checkOption(option);
		}

	}

	/**
	 * Checks the option entered
	 * 
	 * @param option
	 */
	private static void checkOption(String option) {
		switch (option) {
			case "1" :
				System.out.println("These are the states of the FA");
				System.out.println(fa.getStates());
				System.out.println();
				break;

			case "2" :
				System.out.println("This is the alphabet of the FA");
				System.out.println(fa.getAlphabet());
				System.out.println();
				break;

			case "3" :
				System.out.println("These are the transitions of the FA");
				System.out.println(fa.getTransitions());
				System.out.println();
				break;

			case "4" :
				System.out.println("This is the initial state of the FA");
				System.out.println(fa.getInitialState());
				System.out.println();
				break;
				
			case "5" :
				System.out.println("These are the final states of the FA");
				System.out.println(fa.getFinalStates());
				System.out.println();
				break;
				
			case "E" :
				System.exit(0);
		}

	}

	/**
	 * Prints the menu
	 */
	private static void showMenu() {
		System.out.println("\t FA MENU");
		System.out.println("1 Set of states");
		System.out.println("2 Alphabet");
		System.out.println("3 Transitions");
		System.out.println("4 Initial state");
		System.out.println("5 Set of final states");
		System.out.println("E Exit");
	}

	/**
	 * Reads the string entered by console by the user
	 * 
	 * @return
	 */
	@SuppressWarnings("resource")
	private static String ReadString() {
		return new Scanner(System.in).nextLine();
	}

}
