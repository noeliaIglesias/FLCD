package lab4;

import java.util.LinkedList;
import java.util.List;

public class FA {
	private List<String> states = new LinkedList<String>();
	private List<String> alphabet = new LinkedList<String>();
	private List<String> transitions = new LinkedList<String>();
	private List<String> finalStates = new LinkedList<String>();
	private List<Transition> t = new LinkedList<Transition>();
	private List<String> endS = new LinkedList<String>();
	private String initialState;
	private boolean deterministic = false;

	public void parseLines(List<String> lines) {
		int counter = 0;
		for (String s : lines) {
			if (s.trim().isEmpty()) {
				counter++;
				continue;
			}
			try {
				checkOp(s, counter);
			} catch (Exception e) {
				System.out.println("Error");
			}
		}
	}

	/**
	 * Checks what information is in each line and adds it to the correspondent
	 * list
	 * 
	 * @param s
	 * @param counter
	 */
	private void checkOp(String s, int counter) {
		if (counter == 0) {
			states.add(s);
		} else if (counter == 1) {
			alphabet.add(s);
		} else if (counter == 2) {
			String start = String.valueOf(s.charAt(0));
			String word = String.valueOf(s.charAt(2));
			String end = String.valueOf(s.charAt(s.length() - 1));
			Transition tr = new Transition(start, word, end);
			List<String> endS = new LinkedList<String>();
			for (int i = s.length() - 1; i < transitions.size(); i++) {
				endS.add(transitions.get(i));
			}
			tr.setEndState(endS);
			t.add(tr);

		} else if (counter == 3) {
			this.initialState = s;
		} else {
			finalStates.add(s);
		}
	}

	private void checkTransition(String s) {
		int counter = 0;
		for (int i = 0; i < s.length(); i++) {
			String x = String.valueOf(s.charAt(i));

		}

	}

	/**
	 * Returns the list of states of the FA
	 * 
	 * @return
	 */
	public String getStates() {
		String st = "";
		for (String s : states) {
			st += s.toString();
		}
		return st;
	}

	/**
	 * Returns the list of the alphabet of the FA
	 * 
	 * @return
	 */
	public String getAlphabet() {
		String st = "";
		for (String s : alphabet) {
			st += s.toString();
		}
		return st;
	}

	/**
	 * Returns the list of final states of the FA
	 * 
	 * @return
	 */
	public String getFinalStates() {
		String st = "";
		for (String s : finalStates) {
			st += s.toString();
		}
		return st;
	}

	/**
	 * Returns the list of transitions of the FA
	 * 
	 * @return
	 */
	public String getTransitions() {
		String st = "";
		for (String s : transitions) {
			st += s.toString() + "\n";
		}
		return st;
	}

	public String getInitialState() {
		return this.initialState;
	}

	public boolean isDeterministic() {
		return this.deterministic;
	}

	public void checkDeterministic() {
		int counter = 0;
		for (int i = 0; i < t.size(); i++) {
			for (int j = 1; j < t.size(); j++) {
				if (t.get(i).getStartS().equals(t.get(j).getStartS())) {
					if (!t.get(i).getEndS().equals(t.get(j).getEndS())) {
						if (t.get(i).getWord().equals(t.get(j).getWord())) {
							counter++;
						}
					}
				}
			}
		}
		if (counter == 0) {
			this.deterministic = true;
		} else {
			this.deterministic = false;
		}
	}

	public boolean checkWord(String word) {
		String state = this.initialState;
		String[] seq = word.split("");
		for (int i = 0; i < seq.length; i++) {
			String next = continuePath(state, seq[i]);
			if (next == null) {
 				return false;
			}
		}
		return finalStates.contains(state);
	}

	private String continuePath(String start, String letter) {
		for (Transition tr : t) {
			if (tr.getStartS().equals(start) && tr.getWord().equals(letter)) {
				if (getEndS().size() == 1) {
					return getEndS().get(0);
				}
			}
		}
		return null;
	}

	public List<String> getEndS() {
		return this.endS;
	}
}
