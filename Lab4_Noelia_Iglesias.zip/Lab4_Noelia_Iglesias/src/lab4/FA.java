package lab4;

import java.util.LinkedList;
import java.util.List;

public class FA {
	private List<String> states = new LinkedList<String>();
	private List<String> alphabet = new LinkedList<String>();
	private List<String> transitions = new LinkedList<String>();
	private List<String> finalStates = new LinkedList<String>();

	public void parseLines(List<String> lines) {
		int counter = 0;
		for (String s : lines) {
			if (s.trim().isEmpty()) {
				counter++;
				continue;
			}
			try {
				checkOp(s, counter);
			} catch (Exception e) {
				System.out.println("Error");
			}
		}
	}

	/**
	 * Checks what information is in each line and adds it to the correspondent
	 * list
	 * 
	 * @param s
	 * @param counter
	 */
	private void checkOp(String s, int counter) {
		if (counter == 0) {
			states.add(s);
		} else if (counter == 1) {
			alphabet.add(s);
		} else if (counter == 2) {
			transitions.add(s);
		} else {
			finalStates.add(s);
		}
	}

	/**
	 * Returns the list of states of the FA
	 * 
	 * @return
	 */
	public String getStates() {
		String st = "";
		for (String s : states) {
			st += s.toString();
		}
		return st;
	}

	/**
	 * Returns the list of the alphabet of the FA
	 * 
	 * @return
	 */
	public String getAlphabet() {
		String st = "";
		for (String s : alphabet) {
			st += s.toString();
		}
		return st;
	}

	/**
	 * Returns the list of final states of the FA
	 * 
	 * @return
	 */
	public String getFinalStates() {
		String st = "";
		for (String s : finalStates) {
			st += s.toString();
		}
		return st;
	}

	/**
	 * Returns the list of transitions of the FA
	 * 
	 * @return
	 */
	public String getTransitions() {
		String st = "";
		for (String s : transitions) {
			st += s.toString() + "\n";
		}
		return st;
	}

}
