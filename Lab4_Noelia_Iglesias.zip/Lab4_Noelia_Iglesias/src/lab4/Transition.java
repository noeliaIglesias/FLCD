package lab4;

import java.util.List;

public class Transition {
	private String startS;
	private String word;
	private String endS;
	private List<String> endState;

	
	public Transition(String startS, String word, String endS) {
		this.startS = startS;
		this.word = word;
		this.endS = endS;
	}
	
	public String getStartS() {
		return startS;
	}

	public String getWord() {
		return word;
	}

	public String getEndS() {
		return endS;
	}

	public List<String> getEndState() {
		return endState;
	}

	public void setEndState(List<String> endState) {
		this.endState = endState;
	}
	
	
}
