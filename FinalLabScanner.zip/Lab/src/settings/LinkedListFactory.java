package settings;


import lab.LinkedList;
import lab.List;

public class LinkedListFactory implements ListFactory {

	@Override
	public List<String> newList() {
		return new LinkedList<String>();
	}

}
