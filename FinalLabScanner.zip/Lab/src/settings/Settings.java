package settings;

public class Settings {

	public static ListFactory factory;

}
