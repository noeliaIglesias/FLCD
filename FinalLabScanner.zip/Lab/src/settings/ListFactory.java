package settings;

import lab.List;

public interface ListFactory {

	List<String> newList();

}
