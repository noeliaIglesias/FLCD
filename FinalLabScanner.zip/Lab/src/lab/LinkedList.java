package lab;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedList<T> implements List<T> {

	private Node<T> head;
	private int numberOfElements;
	
	public LinkedList() {
		head = null;
		numberOfElements = 0;
	}
	
	@Override
	public int size() {
		return this.numberOfElements;
	}

	@Override
	public boolean isEmpty() {
		return this.size() == 0;
	}

	@Override
	public boolean contains(T o) {
		if (isEmpty() || o == null) {
			return false;
		} else if (indexOf(o) >= 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean add(T element) {
		if (element == null) {
			throw new IllegalArgumentException();
		}
		if (isEmpty()) {
			addFirst(element);
		} else {
			Node<T> last = getNode(size() - 1);
			last.next = new Node<>(element, null);
			this.numberOfElements++;
		}
		return false;
	}

	@Override
	public boolean remove(T o) {
		if (isEmpty() || o == null || !contains(o)) {
			return false;
		}
		int pos = indexOf(o);
		remove(pos);
		return true;
	}

	@Override
	public void clear() {
		head = null;
		numberOfElements = 0;
	}

	@Override
	public T get(int index) {
		if (size() < 0 || index > size() || index < 0) {
			throw new IndexOutOfBoundsException();
		}
		return getNode(index).value;
	}

	public Node<T> getNode(int index) {
		if (size() < 0 || index > size() || index < 0) {
			throw new IndexOutOfBoundsException();
		}
		Node<T> res = head;
		for (int i = 0; i < index; i++) {
			res = res.next;
		}
		return res;
	}

	@Override
	public T set(int index, T element) {
		T aux;
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException();
		}
		if (element == null) {
			throw new IllegalArgumentException();
		}
		aux = getNode(index).value;
		getNode(index).value = element;
		return aux;
	}

	@SuppressWarnings({"unchecked", "rawtypes"})
	@Override
	public void add(int index, T element) {
		if (index < 0) {
			throw new IndexOutOfBoundsException();
		}
		if (element == null) {
			throw new IllegalArgumentException();
		}
		if (head == null && index > 0) {
			throw new IndexOutOfBoundsException();
		}
		if (index == 0) {
			addFirst(element);
		} else {
			Node<T> previous = getNode(index - 1);
			previous.next = new Node(element, previous.next);
			numberOfElements++;
		}
	}

	@SuppressWarnings({"unchecked", "rawtypes"})
	public void addFirst(T element) {
		head = new Node(element, head);
		numberOfElements++;
	}

	@Override
	public T remove(int index) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException();
		}
		if (this.isEmpty()) {
			return null;
		}
		T value;
		if (index == 0) {
			value = this.head.value;
			this.head = this.head.next;
		} else {
			Node<T> previous = getNode(index - 1);
			value = previous.next.value;
			previous.next = previous.next.next;
		}
		this.numberOfElements--;
		return value;
	}

	@Override
	public int indexOf(Object o) {
		@SuppressWarnings("rawtypes")
		Node n = head;
		int i = 0;
		if (o == null) {
			throw new IllegalArgumentException();
		}
		while (n != null && !n.value.equals(o)) {
			n = n.next;
			i++;
		}
		if (i == size()) {
			return -1;
		}
		return i;
	}

	@Override
	public String toString() {
		String result = "[";
		if (isEmpty()) {
			result = result + "]";
		} else {
			for (int i = 0; i < size() - 1; i++) {
				result = result + get(i) + ", ";
			}
			result = result + get(size() - 1) + "]";
		}
		return result;
	}

	@Override
	public int hashCode() {
		int hashCode = 1;
		for (int i = 0; i < size(); i++) {
			hashCode = 31 * hashCode + (get(i) == null ? 0 : get(i).hashCode());
		}
		return hashCode;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof List)) {
			return false;
		}
		List<?> list = (List<?>) o;

		if (list.size() != size()) {
			return false;
		}
		if (list.size() == 0 && size() == 0) {
			return true;
		}
		for (int i = 0; i < size(); i++) {
			if (!(get(i).equals(list.get(i)))) {
				return false;
			}
		}
		return true;
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public Iterator<T> iterator() {
		return new LinkedListIterator(this);
	}

	public class LinkedListIterator<U> implements Iterator<U> {
		@SuppressWarnings("unused")
		private LinkedList<U> list;
		private Node<U> n;

		public LinkedListIterator(LinkedList<U> list) {
			this.list = list;
			n = list.head;
		}

		@Override
		public boolean hasNext() {
			return n != null;
		}

		@Override
		public U next() {
			if (hasNext()) {
				U o = n.value;
				n = n.next;
				return o;
			}
			throw new NoSuchElementException();
		}
	}
}
