package lab;

public class Node<U> {
	U value;
	Node<U> next;

	public Node(U value, Node<U> next) {
		this.value = value;
		this.next = next;
	}
}
