package lab4;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class FileUtil {

	private static String[] separators = {"(", ")", "\n", "[", "]", "{", "}", ":",
			";",};
	// private static String[] separators = {"\n", "{", "}",";"};

	public static List<String> loadFile(String fileName) {

		String line;
		//String[] productData = null;
		List<String> lines = new LinkedList<String>();

		try {
			BufferedReader file = new BufferedReader(new FileReader(fileName));
			while (file.ready()) {
				line = file.readLine();
				lines.add(line);
				/*
				 * for(String s : separators) { if(line.contains(s)) {
				 * productData = line.split(s);
				 * productsList.add(productData[0]); } }
				 */
				/*
				 * for(int i = 0; i < separators.length; i++){
				 * while(line.contains(separators[i])) { productData =
				 * line.split(separators[i]); productsList.add(productData[0]);
				 * } }
				 */
				//productData = line.split("\n");
				//productsList.add(productData.);

			}
			/*for (int i = 0; i < lines.size(); i++) {
				for (int j = 0; j < separators.length; j++) {
					if (lines.get(i).contains(separators[j])) {
						productData = lines.get(i).split(separators[i]);
						
						list.add(productData);
						//String z = lines.get(i);
						/*for(int q = 0; q < z; q++) {
							productsList.add(productData[q]);
						}*/
					//}
				//}
				// productData = line.split("\n");
				// productsList.add(productData[0]);
			//}
			file.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("File not found.");
		} catch (IOException ioe) {
			new RuntimeException("I/O Error.");
		}
		return lines;
	}
}
