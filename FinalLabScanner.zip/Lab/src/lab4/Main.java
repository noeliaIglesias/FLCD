package lab4;

import java.util.LinkedList;
import java.util.List;

public class Main {

	private static FileUtil fileUtil;
	private static Lab3 lab;
	private static List<String> list = new LinkedList<String>();

	public static void main(String[] args) {
		fileUtil = new FileUtil();
		lab = new Lab3();
		list = FileUtil.loadFile("program.txt");
		lab.parse(list);
		lab.printSymbols();

	}
}
