package lab4;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Lab3 {
	private final static List<String> OPERATORS = Arrays.asList("+", "-", "*",
			"/", ":=", "<", "<=", "=", ">=", "++", "--", "+=", "-=", "%");
	private final static List<String> RESERVED = Arrays.asList("array", "char",
			"const", "do", "else", "if", "int", "of", "program", "read",
			"write", "then", "var", "while", "write", "for", "foreach", "break",
			"return", "print");
	private final static List<String> SEPARATORS = Arrays.asList(" ", "(", ")",
			"\n", "[", "]", "{", "}", ":", ";");
	private final static List<String> NUMBERS = Arrays.asList("0", "1", "2",
			"3", "4", "5", "6", "7", "8", "9");
	private final static List<String> WORDS = Arrays.asList("a", "b", "c", "d",
			"e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
			"r", "s", "t", "u", "v", "w", "x", "y", "z");

	private int lineNum;
	private boolean res = false;
	private boolean num = false;
	private boolean op = false;
	private boolean w = false;
	private boolean cnts = false;

	private List<String> identifiers = new LinkedList<String>();
	private List<String> symbols = new LinkedList<String>();

	public List<String> parse(List<String> lines) {
		lineNum = 0;
		List<String> sol = new LinkedList<String>();
		for (String s : lines) {
			if (s.trim().isEmpty()) {
				continue;
			}
			try {
				List<String> line = parseLine(s);
				for (String q : line) {
					sol.add(q);
				}
			} catch (Exception e) {
				System.out.println("Error");
			}
			lineNum++;
		}
		sol = check(sol);
		print(sol);
		return sol;

	}

	private List<String> parseLine(String line) {
		List<String> x = null;
		for (int i = 0; i < SEPARATORS.size(); i++) {
			if (line.contains(SEPARATORS.get(i))) {
				x = Arrays.asList(line.split(SEPARATORS.get(i)));
				break;
			}
		}
		return x;
	}

	public void print(List<String> sol) {
		for (int i = 0; i < sol.size(); i++) {
			System.out.println(sol.get(i));
		}
	}

	private List<String> check(List<String> lines) {
		List<String> errors = new LinkedList<String>();
		int counter = 0;
		int n = -1;
		checkIdentifiers(lines, errors, counter, n);
		return errors;
	}

	private void checkIdentifiers(List<String> lines, List<String> errors,
			int counter, int n) {
		for (int i = 0; i < lines.size(); i++) {
			this.res = false;
			this.num = false;
			this.op = false;
			this.w = false;
			this.cnts = false;
			if (lines.get(i).length() > 1) {
				checkSeparator(lines, errors, i);
				checkReserved(lines, errors, counter, i, n);
				checkOperator(lines, errors, i);
				checkNumber(lines, errors, i);
				counter = checkWord(lines, errors, i, counter);

			} else if (lines.get(i).length() == 1) {
				if (num) {
					errors.add(lines.get(i));
				} else {
					counter = checkAlphabet(lines, errors, i, counter);
					counter = checkConst(lines, errors, i , counter);
				}
				if (!w && !cnts) {
					errors.add(lines.get(i) + " " + n);
				}

			}
		}

	}

	private int checkConst(List<String> lines, List<String> errors, int i,
			int counter) {
		for(int j = 0; j < NUMBERS.size(); j++) {
			if(lines.get(i).equals(NUMBERS.get(j))) {
				String s = lines.get(i) + " CONSTANT " + counter;
				errors.add(s);
				symbols.add(lines.get(i));
				symbols.add(String.valueOf(counter));
				counter++;
				this.cnts = true;
			}
		}
		return counter;
	}

	private int checkAlphabet(List<String> lines, List<String> errors, int i,
			int counter) {
		for (int j = 0; j < WORDS.size(); j++) {
			if (lines.get(i).equals(WORDS.get(j))) {
				if (!checkId(lines.get(i))) {
					String word = lines.get(i) + " IDENTIFIER " + counter;
					errors.add(word);
					identifiers.add(lines.get(i));
					symbols.add(lines.get(i));
					symbols.add(String.valueOf(counter));
					counter++;
					this.w = true;
				}else {
					this.w = true;
				}
			}
		}
		return counter;
	}

	private int checkWord(List<String> lines, List<String> errors, int i,
			int counter) {
		if (lines.get(i).equals(lines.get(i).toString())) {
			if (!this.res && !this.num) {
				if (!checkId(lines.get(i))) {
					errors.add(lines.get(i) + " IDENTIFIER " + counter);
					identifiers.add(lines.get(i));
					symbols.add(lines.get(i));
					symbols.add(String.valueOf(counter));
					counter++;
				} else {
				}
			}

		}
		return counter;

	}

	private boolean checkId(String string) {
		for (String id : identifiers) {
			if (string.equals(id)) {
				return true;
			}
		}
		return false;
	}

	private void checkNumber(List<String> lines, List<String> errors, int i) {
		for (int j = 0; j < NUMBERS.size(); j++) {
			if (String.valueOf(lines.get(i).charAt(0)).equals(NUMBERS.get(j))) {
				String error = lines.get(i) + " LEXICAL ERROR, NUMBER "
						+ NUMBERS.get(j);
				errors.add(error);
				this.num = true;
			}
		}

	}

	private void checkOperator(List<String> lines, List<String> errors, int i) {
		for (int j = 0; j < OPERATORS.size(); j++) {
			if (String.valueOf(lines.get(i).charAt(0))
					.equals(OPERATORS.get(j))) {
				String error = lines.get(i) + " LEXICAL ERROR, OPERATOR "
						+ OPERATORS.get(j);
				errors.add(error);
				this.op = true;
			}
		}
	}

	private void checkReserved(List<String> lines, List<String> errors,
			int counter, int i, int n) {
		for (int j = 0; j < RESERVED.size(); j++) {
			if (lines.get(i).equals(RESERVED.get(j))) {
				String cnst = lines.get(i);
				counter++;
				errors.add(cnst + " " + n);
				this.res = true;
			}
		}

	}

	private void checkSeparator(List<String> lines, List<String> errors,
			int i) {
		for (int j = 0; j < SEPARATORS.size(); j++) {
			if (String.valueOf(lines.get(i).charAt(0))
					.equals(SEPARATORS.get(j))) {
				String error = lines.get(i) + " LEXICAL ERROR, SEPARATOR "
						+ SEPARATORS.get(j);
				errors.add(error);
			}
		}
	}
	
	public void printSymbols() {
		System.out.println();
		System.out.println("Symbol"+ "\t" + "value");
		for(int i = 0; i < symbols.size(); i++) {
			if(i < symbols.size() - 1) {
				System.out.println(symbols.get(i) + "\t"+ symbols.get(i+1));
				i = i + 1;
			}
			
		}
	}

}