package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

/**
 * 

 *
 */
public class RemoveFromPositionTests {

	private List<String> list;
	private String s;
	private String s1;
	private String s2;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
		s = "A";
		s1 = "B";
		s2 = "C";
	}

	/**
	 * object in the first position
	 */
	@Test
	public void testFirstPosition() {
		list.add("A");
		list.add("B");
		list.add("C");
		
		Object returned = list.remove(0);
		
		assertEquals("A", returned);
		assertEquals("B", list.get(0));
		assertEquals(false, list.contains("A"));
		assertEquals(2, list.size());
	}

	/**
	 * object in the last position
	 */
	@Test
	public void testLastPosition() {
		list.add("A");
		list.add("B");
		list.add("C");
		
		Object returned = list.remove(2);
		
		assertEquals("C", returned);
		assertEquals("[A, B]", list.toString() );
	}

	/**
	 * middle position
	 */
	@Test
	public void testMiddlePosition() {
		list.add(s);
		list.add(s1);
		list.add(s2);
		
		assertEquals(s1, list.remove(1));
		assertEquals(s2 ,list.get(1));
		assertEquals(false, list.contains(s1));
		assertEquals(2, list.size());
	}
		

	/**
	 * Object out of bounds an exception is thrown
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void testOutOfBoundsPosition() {
		list.add(s);
		list.add(s1);
		list.add(s2);
		
		list.remove(4);
	}

}
