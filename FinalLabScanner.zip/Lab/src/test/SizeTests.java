package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

/**
 * 
 * 
 *
 */
public class SizeTests {

	private List<String> list;
	private String s;
	private String s1;
	private String s2;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
		s = "A";
		s1 = "B";
		s2 = "C";
	}

	/**
	 * empty list
	 */
	@Test
	public void testEmptyList() {
		assertEquals(list.size(), 0);
	}

	/**
	 * one element in the list
	 */
	@Test
	public void testOneElement() {
		list.add(s);
		assertEquals(list.size(), 1);
	}

	/**
	 * several elements in the list
	 */
	@Test
	public void testSeveralElements() {
		list.add(s);
		list.add(s1);
		list.add(s2);

		assertEquals(list.size(), 3);
	}
}
