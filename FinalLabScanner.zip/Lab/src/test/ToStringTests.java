package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

/**
 * 
 */
public class ToStringTests {
	
	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/**
	 * For an empty list
	 */
	@Test
	public void EmptyListTest() {
		String expected = "[]";
		
		assertEquals(expected, list.toString());
	}
	
	
	/**
	 * For a list with 2 elements
	 */
	@Test
	public void testWithOneElement() {
		list.add( "A" );
		String expected = "[A]";
		
		assertEquals(expected, list.toString());
	}

	/**
	 * For a list with 2 elements
	 */
	@Test
	public void ListTest() {
		list.add("A");
		list.add("B");
		String expected = "[A, B]";
		
		assertEquals(expected, list.toString());
	}

}
