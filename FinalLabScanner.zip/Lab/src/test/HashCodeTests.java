package test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;


/**
 * 
 *
 */
public class HashCodeTests {

	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/**
	 * Empty List
	 */
	@Test
	public void testEmptyList() {
		int hashCode = 1;
		
		assertTrue(hashCode == list.hashCode());
	}

	/**
	 * For a List with elements
	 */
	@Test
	public void testListWithElements() {
		list.add("LIST");
		list.add("LIST2");
		list.add("LIST3");
		
		int hashCode = computeExpectedHashCode();
		assertTrue(hashCode == list.hashCode());
	}

	private int computeExpectedHashCode() {
		int hashCode = 1;
		for (int i = 0; i < list.size(); i++) {
			hashCode = 31 * hashCode
					+ (list.get(i) == null ? 0 : list.get(i).hashCode());
		}
		return hashCode;
	}

}
