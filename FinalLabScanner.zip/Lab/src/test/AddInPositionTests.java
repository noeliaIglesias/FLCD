package test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

/**
 *
 */
public class AddInPositionTests {
	
	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/**
	 * Add one element to a new list
	 */
	@Test
	public void oneElementTest() {
		String obj = "A";
		list.add(0, obj);
		
		assertTrue(list.size() == 1);
		assertTrue("[A]".equals( list.toString() ));
	}
	
	/**
	 * Add one element non repeated
	 */
	@Test
	public void nonRepeatedTest() {
		String obj = "A";
		String obj1 = "B";
		list.add(0, obj);
		list.add(1, obj1);
		
		assertTrue(list.size() == 2);
		assertTrue("[A, B]".equals( list.toString() ));
	}
	
	/**
	 * Add an element repeated
	 */
	@Test
	public void repeatedTest() {
		String obj = "A";
		list.add(0, obj);
		list.add(1, obj);

		assertTrue(list.size() == 2);
		assertTrue("[A, A]".equals( list.toString() ));
	}
	
	/**
	 * Add an element null
	 */
	@Test (expected = IllegalArgumentException.class)
	public void nullTest() {
		list.add(0, null);
	}
	
	/**
	 * Add an element in negative size
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void negativePositionTest() {	
		list.add(-1, "A");
	}
	
	/**
	 * Add an element in index greater than size
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void greaterIndexTest() {
		list.add(1, "A"); 
	}
	
	/**
	 * Add an element in an already occupied position
	 */
	@Test
	public void alreadyOccupiedTest() {
		list.add(0, "A");
		list.add(0, "B");
		String expected = "[B, A]";
		
		assertTrue(list.size() == 2);
		assertTrue(expected.equals( list.toString() ));
	}
	
	/**
	 * Add the same obj to the same pos
	 */
	@Test
	public void sameObjSamePosTest() {
		String obj = "A";
		list.add(0, obj);
		list.add(0, obj);
		String expected = "[A, A]";
		
		assertTrue(list.size() == 2);
		assertTrue(expected.equals( list.toString() ));
	}
	
	/**
	 * Add to the last element
	 */
	@Test
	public void test() {
		list.add(list.size(), "A"); 
		list.add(list.size(), "B"); 
		list.add(list.size(), "C");
		String expected = "[A, B, C]";

		assertTrue(list.size() == 3);
		assertTrue(expected.equals( list.toString() ));
	}
}

