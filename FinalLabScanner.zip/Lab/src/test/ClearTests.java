package test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

public class ClearTests {

	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/**
	 * Clear has no effect on an empty list
	 */
	@Test
	public void test() {
		list.clear();

		assertTrue(list.size() == 0);
	}

	/**
	 * Clears a list with one element
	 */
	@Test
	public void testClearWithOne() {
		list.add("A");

		list.clear();

		assertTrue(list.size() == 0);
	}

	/**
	 * Clears a list will several elements
	 */
	@Test
	public void testClearWithSeveral() {
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");

		list.clear();

		assertTrue(list.size() == 0);
		assertFalse(list.contains("A"));
	}

}
