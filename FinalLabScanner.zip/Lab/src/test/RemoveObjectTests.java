package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;
/**
 * 
 *
 */
public class RemoveObjectTests {
	private List<String> list;
	private String s;
	private String s1;
	private String s2;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
		s = "A";
		s1 = "B";
		s2 = "C";
	}

	/**
	 * new list that is empty
	 */
	@Test
	public void testEmptyList() {
		boolean res = list.remove(s);
		
		assertTrue( res == false );
	}

	/**
	 * is the object in the collection?
	 */
	@Test
	public void testNonExistingObject() {
		list.add("A");
		list.add("B");
		
		boolean res = list.remove( "C" );
		
		assertTrue( res == false );
	}

	/**
	 * removes only one single object when there are equal objects
	 */
	@Test
	public void testDoubleExistingObject() {
		list.add(s1);
		list.add(s);
		list.add(s1);

		list.remove(s1);
		assertEquals(s1, list.get(1));
		assertEquals(s, list.get(0));
		assertEquals(true, list.contains(s1));
	}

	/**
	 * are several elements but only one of the searched object
	 */
	@Test
	public void testOneExistingObject() {
		list.add(s);
		list.add(s1);
		list.add(s2);

		list.remove(s);
		assertEquals(s2, list.get(1));
		assertEquals(s1, list.get(0));
		assertEquals(false, list.contains(s));
	}

	/**
	 * object == null
	 */
	@Test
	public void testNullPointerObject() {
		s = null;

		assertTrue(list.remove(s) == false);

	}

}