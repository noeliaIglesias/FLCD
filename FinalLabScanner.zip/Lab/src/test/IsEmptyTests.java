package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

/**
 
 *
 */
public class IsEmptyTests {
	
	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/**
	 * Test an empty list
	 */
	@Test
	public void test1() {
		assertEquals(true, list.isEmpty());
	}

	/**
	 * Not Empty all removed
	 */
	@Test
	public void test2() {
		list.add("a");
		list.add("b");
		list.clear();
		
		assertTrue(list.isEmpty());
	}

	/**
	 * Empty list with add elements
	 */
	@Test
	public void test3() {
		list.add("a");
		list.add("b");

		assertTrue(!list.isEmpty());
	}
	
	/**
	 * Full list removing only one element.
	 */
	@Test
	public void test4() {
		list.add("a");
		list.add("b");
		list.add("c");
		
		list.remove("c");
	}
}
