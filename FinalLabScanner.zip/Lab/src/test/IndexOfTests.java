package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

/**
 * 
 *
 *
 */
public class IndexOfTests {

	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/**
	 * For an existing element
	 */
	@Test
	public void ExistingElementTest() {
		String x = "AA";
		String y = "BB";
		list.add(x);
		list.add(y);
		
		assertEquals(list.indexOf(x), 0);
		assertEquals(list.indexOf(y), 1);
	}

	/**
	 * For a non contained element
	 */
	@Test
	public void nonContainedTest() {
		String x = "AA";
		String y = "BB";
		list.add(x);
		assertEquals(list.indexOf(y), -1);
	}

	/**
	 * For a null element
	 */
	@Test(expected = IllegalArgumentException.class)
	public void nullObjectTest() {
		//list.add("A");
		//list.add(null);
		
		String a = "A";
		a = null;
		list.add(a);
		
	}

	/**
	 * For multiple appearances
	 */
	@Test
	public void multipleAppearancesTest() {
		String x = "AA";
		String y = "BB";
		list.add(y);
		list.add(x);
		list.add(y);
		list.add(x);

		assertEquals(list.indexOf(y), 0);
		assertEquals(list.indexOf(x), 1);
	}

	/**
	 * For an empty list
	 */
	@Test
	public void EmptyListTest() {
		String x = "AA";
		assertEquals(list.indexOf(x), -1);
	}
}
