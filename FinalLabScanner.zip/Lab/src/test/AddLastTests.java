package test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;
/**
 * 
 *
 */
public class AddLastTests {

	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/**
	 * Empty List ArrayList
	 */
	@Test
	public void testEmptyList() {
		list.add(0, "LIST");

		assertTrue(list.contains("LIST"));
		assertTrue(list.get(list.size() - 1).equals("LIST"));
		assertTrue(list.size() == 1);
	}

	/**
	 * For a List with elements ArrayList
	 */
	@Test
	public void testListWithElements() {
		list.add("LIST");
		list.add("LIST2");
		list.add("LIST3");

		list.add(2, "LIST4");

		assertTrue(list.contains("LIST4"));
		Object object = list.get(2);
		assertTrue(object.equals("LIST4"));
		assertTrue(list.size() == 4);
	}

	/**
	 * Empty List LinkedList
	 */
	@Test
	public void testEmptyListLinked() {
		list.add("LIST");

		assertTrue(list.contains("LIST"));
		assertTrue(list.get(list.size() - 1).equals("LIST"));
		assertTrue(list.size() == 1);
	}

}
