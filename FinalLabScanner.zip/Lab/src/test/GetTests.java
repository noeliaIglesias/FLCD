package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

/**
 * 
 
 *
 */
public class GetTests {
	
	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}
	
	/**
	 * empty list
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void test1() {
		list.get(1);
	}
	
	/**
	 * get first element
	 */
	@Test
	public void test2() {
		list.add("a");
		list.add("b");
		
		assertEquals("a", list.get(0));
	}

	/**
	 * get last element
	 */
	@Test
	public void test3() {
		list.add("a");
		list.add("b");
		
		assertEquals("b", list.get(list.size() - 1));
	}
	
	/**
	 * get middle element
	 */
	@Test
	public void test4() {
		list.add("a");
		list.add("b");
		list.add("c");
		
		assertEquals("b", list.get(1));
	}

	/**
	 * We try to get a negative index.
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void test5() {
		list.add("a");
		list.add("b");
		list.add("c");
		
		list.get(-1);
	}
	
	
	/**
	 * We try to get an index that is bigger than the size of the list.
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void test6() {
		list.add("a");
		list.add("b");
		list.add("c");
		
		list.get(8);
	}
}

