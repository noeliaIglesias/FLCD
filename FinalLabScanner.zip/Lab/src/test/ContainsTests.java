package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

/**
 * 
 * 
 *
 */
public class ContainsTests {
	
	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/**
	 * For an empty collection
	 */
	@Test
	public void emptyCollectionTest() {
		String x = "AA";
		assertEquals(list.contains(x), false);
	}
	
	/**
	 * For a non contained object
	 */
	@Test
	public void nonContainedTest() {
		String x = "AA";
		String y = "BB";
		list.add(x);
		assertEquals(list.contains(y), false);
	}

	
	/**
	 * For an existing object
	 */	
	@Test
	public void existingObjectTest() {
		String x = "AA";
		String y = "BB";
		list.add(x);
		list.add(y);
		assertEquals(list.contains(y), true);
		assertEquals(list.contains(x), true);
	}
	
	/**
	 * For multiple appearances 
	 */
	@Test
	public void multipleAppearancesTest() {
		String x = "AA";
		String y = "BB";
		list.add(x);
		list.add(y);
		list.add(x);
		assertEquals(list.contains(x), true);
	}
}
