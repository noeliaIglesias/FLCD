package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import lab.List;
import settings.Settings;

public class SetTests {

	private List<String> list;

	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
		list.add("a");
		list.add("b");
		list.add("c");
	}

	@Test
	public void testSetOneElement() {
		Object returned = list.set(0, "x");
		
		assertEquals("a", returned);
		assertEquals("x", list.get(0));
	}

	@Test
	public void testSetElementLast() {
		list.set(list.size() - 1, "d");
		assertEquals("d", list.set(list.size() - 1, "y"));
	}

}