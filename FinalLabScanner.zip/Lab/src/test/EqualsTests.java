package test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

//import uo.mp.collections.ArrayList;
import lab.LinkedList;
import lab.List;
import settings.Settings;

/**
 * 
 *
 *
 */
public class EqualsTests {

	private List<String> list1;
	private List<String> list2;

	private LinkedList<String> linkedList1;
	private LinkedList<String> linkedList2;

	@Before
	public void setUp() throws Exception {
		list1 = Settings.factory.newList();
		list2 = Settings.factory.newList();

		linkedList1 = new LinkedList<String>();
		linkedList2 = new LinkedList<String>();
	}

	/**
	 * Compare two empty lists
	 */
	@Test
	public void testEmptyLists() {

		assertTrue(list1.equals(list2));

		assertTrue(linkedList1.equals(linkedList2));
		assertTrue(linkedList2.equals(linkedList1));
	}

	/**
	 * Compare two one object equal lists
	 */
	@Test
	public void testOneObjectList() {

		adjustToOneEqual();

		assertTrue(list1.equals(list2));

		assertTrue(linkedList1.equals(linkedList2));
		assertTrue(linkedList2.equals(linkedList1));

	}

	public void adjustToOneEqual() {
		String aux = "Hello World";

		list1.add(aux);
		list2.add(aux);

		linkedList1.add(aux);
		linkedList2.add(aux);
	}

	/**
	 * Compare two one object not equals lists
	 */
	@Test
	public void testOneObjectNotEqualList() {

		adjustToOneNotEqual();

		assertFalse(list1.equals(list2));

		assertFalse(linkedList1.equals(linkedList2));
		assertFalse(linkedList2.equals(linkedList1));
	}

	public void adjustToOneNotEqual() {
		String aux = "A";
		String aux2 = "B";

		list1.add(aux);
		list2.add(aux2);

		linkedList1.add(aux);
		linkedList2.add(aux2);
	}

	/**
	 * Compare two several objects equal lists
	 */
	@Test
	public void testTwoObjectList() {

		adjustToTwoEqual();

		assertTrue(list1.equals(list2));

		assertTrue(linkedList1.equals(linkedList2));
		assertTrue(linkedList2.equals(linkedList1));
	}

	public void adjustToTwoEqual() {
		String aux = "A";
		String aux2 = "B";

		list1.add(aux);
		list1.add(aux2);
		list2.add(aux);
		list2.add(aux2);

		linkedList1.add(aux);
		linkedList1.add(aux2);
		linkedList2.add(aux);
		linkedList2.add(aux2);
	}

	/**
	 * Compare two several objects not equal lists
	 */
	@Test
	public void testTwoNotEqualObjectList() {

		adjustToTwoNotEqual();

		assertFalse(list1.equals(list2));

		assertFalse(linkedList1.equals(linkedList2));
		assertFalse(linkedList2.equals(linkedList1));

	}

	public void adjustToTwoNotEqual() {
		String aux = "A";
		String aux2 = "B";

		list1.add(aux);
		list1.add(aux);
		list2.add(aux2);
		list2.add(aux2);

		linkedList1.add(aux);
		linkedList1.add(aux);
		linkedList2.add(aux2);
		linkedList2.add(aux2);
	}

	/**
	 * Compare two different size lists
	 */
	@Test
	public void testTwoDifSizeList() {

		adjustToTwoDifSize();

		assertFalse(list1.equals(list2));

		assertFalse(linkedList1.equals(linkedList2));
		assertFalse(linkedList2.equals(linkedList1));

	}

	public void adjustToTwoDifSize() {
		String aux = "A";
		String aux2 = "B";

		list1.add(aux);
		list1.add(aux2);
		list2.add(aux);

		linkedList1.add(aux);
		linkedList1.add(aux2);
		linkedList2.add(aux);
	}

	/**
	 * Compare two several equal objects in different positions lists.
	 */
	@Test
	public void testTwoDifPos() {

		adjustToTwoDifPos();

		assertFalse(list1.equals(list2));

		assertFalse(linkedList1.equals(linkedList2));
		assertFalse(linkedList2.equals(linkedList1));

	}

	public void adjustToTwoDifPos() {
		String aux = "A";
		String aux2 = "B";

		list1.add(aux);
		list1.add(aux2);
		list2.add(aux2);
		list2.add(aux);

		linkedList1.add(aux);
		linkedList1.add(aux2);
		linkedList2.add(aux2);
		linkedList2.add(aux);
	}

	/**
	 * Compare the same list
	 */
	@Test
	public void testSameList() {

		adjustElements();

		assertTrue(list1.equals(list1));

		assertTrue(linkedList1.equals(linkedList1));
	}

	public void adjustElements() {
		String aux = "A";
		String aux2 = "B";

		list1.add(aux);
		list1.add(aux2);

		linkedList1.add(aux);
		linkedList1.add(aux2);
	}

	/**
	 * Compare list with Object.
	 */
	@Test
	public void testWithObject() {

		Integer num = new Integer(0);

		assertFalse(list1.equals(num));

		assertFalse(linkedList1.equals(num));
	}

	/**
	 * Compare list with null.
	 */

	@Test
	public void testWithNull() {

		assertFalse(list1.equals(null));

		assertFalse(linkedList1.equals(null));
	}

}
