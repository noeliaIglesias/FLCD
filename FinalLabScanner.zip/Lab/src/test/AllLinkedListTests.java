package test;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import settings.LinkedListFactory;

@RunWith(Suite.class)
@SuiteClasses({AddInPositionTests.class, AddLastTests.class, ClearTests.class,
		ContainsTests.class, EqualsTests.class, GetTests.class,
		HashCodeTests.class, IndexOfTests.class, IsEmptyTests.class,
		RemoveFromPositionTests.class, RemoveObjectTests.class, SetTests.class,
		SizeTests.class, ToStringTests.class})

public class AllLinkedListTests {

	@BeforeClass
	public static void setUp() {
		settings.Settings.factory = new LinkedListFactory();
	}
}
